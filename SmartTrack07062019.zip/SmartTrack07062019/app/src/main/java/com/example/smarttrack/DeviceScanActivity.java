package com.example.smarttrack;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.ListActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.provider.SyncStateContract;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class DeviceScanActivity extends ListActivity  {

    private static final String TAG = "HELL";

    private LeDeviceListAdapter mLeDeviceListAdapter;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeScanner mBluetoothLeScanner;
    private Handler mHandler;

    private Button button_scan;
    private boolean mScanning;

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_FINE_LOCATION = 1;
    // Stops scanning after 5 seconds.
    private static final long SCAN_PERIOD = 10000;
    private AnimationDrawable drawable;
    String deviceName;

    private DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_scan);
        mHandler = new Handler();

        myDb = new DatabaseHelper(this);

        //UI
        button_scan = findViewById(R.id.scanBtn);

        getListView().setVisibility(View.INVISIBLE);

        drawable = new AnimationDrawable();
        drawable.addFrame(new ColorDrawable(getResources().getColor(R.color.gradient_end_2)), 400);
        drawable.addFrame(new ColorDrawable(getResources().getColor(R.color.gradient_end_3)), 400);
        drawable.setOneShot(false);

        button_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!mScanning){
                    Log.d(TAG, "onClick: Starting scan");
                    mLeDeviceListAdapter.clear();

                    scanLeDevice(true);

                    mScanning = true;
                    button_scan.setText(getString(R.string.scanning));
                    button_scan.setBackground(drawable);
                    drawable.setVisible(true, true);
                    drawable.start();
                    getListView().setVisibility(View.VISIBLE);

                } else{
                    Log.d(TAG, "onClick: Stopped scanning");

                    scanLeDevice(false);

                    mScanning = false;
                    button_scan.setText(R.string.scan_Btn);
                    button_scan.setBackgroundResource(R.drawable.refresh_button);
                    drawable.setVisible(false, true);
                }
            }
        });

        // Initializes a Bluetooth adapter.  For API level 18 and above, get a reference to
        // BluetoothAdapter through BluetoothManager.
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        // Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.error_bluetooth_not_supported, Toast.LENGTH_SHORT).show();

            AlertDialog alertDialog = new AlertDialog.Builder(DeviceScanActivity.this).create();
            alertDialog.setTitle("Alert");
            alertDialog.setMessage("Bluetooth is not supported on this device");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
            alertDialog.show();
            return;
        }

        mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();
    }

    private void scanLeDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    button_scan.setText(R.string.scan_Btn);
                    drawable.stop();
                    mScanning = false;
                    button_scan.setBackgroundResource(R.drawable.refresh_button);

                    mBluetoothLeScanner.stopScan(mLeScanCallback);
                }
            }, SCAN_PERIOD);

            List<ScanFilter> filter = new ArrayList<>();
            ScanFilter scanFilter = new ScanFilter.Builder()
                    .setServiceUuid(ParcelUuid.fromString(BLE_UUID.SERVICE_INFORMATION))
                    .build();
            filter.add(scanFilter);
            ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            mScanning = false;
            mBluetoothLeScanner.startScan(filter, settings, mLeScanCallback);
        } else {
            mScanning = true;
            mBluetoothLeScanner.stopScan(mLeScanCallback);
        }
    }


    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        final BluetoothDevice device = mLeDeviceListAdapter.getDevice(position);
        if (device == null) return;

        boolean success = myDb.insertDevice(device.getAddress(), device.getName(), device.getName());

        if(success)
            Toast.makeText(this, "Device added", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "Device not added", Toast.LENGTH_SHORT).show();

        final Intent intent = new Intent(this, DeviceMainActivity.class);
        //intent.putExtra(DeviceMainActivity.EXTRAS_DEVICE_NAME, deviceName);
        intent.putExtra(DeviceMainActivity.EXTRAS_DEVICE_ADDRESS, device.getAddress());


        if (mScanning) {
            Log.d(TAG, "onListItemClick: Stopped scan to next activity");

            mBluetoothLeScanner.stopScan(mLeScanCallback);
            mScanning = false;
        }
        startActivity(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        scanLeDevice(false);
        mLeDeviceListAdapter.clear();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Ensures Bluetooth is enabled on the device.  If Bluetooth is not currently enabled,
        // fire an intent to display a dialog asking the user to grant permission to enable it.
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);

        }

        // Initializes list view adapter.
        mLeDeviceListAdapter = new LeDeviceListAdapter();
        setListAdapter(mLeDeviceListAdapter);

        Toast.makeText(DeviceScanActivity.this, "21 is called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onResume: 21 is called");
        scanLeDevice(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    private class LeDeviceListAdapter extends BaseAdapter {
        private ArrayList<BluetoothDevice> mLeDevices;
        private ArrayList<Integer> mLeRssi;
        private LayoutInflater mInflator;

        public LeDeviceListAdapter() {
            super();
            mLeDevices = new ArrayList<>();
            mLeRssi = new ArrayList<>();
            mInflator = DeviceScanActivity.this.getLayoutInflater();
        }

        public void addDevice(BluetoothDevice device, int rssi) {
            if (!mLeDevices.contains(device)) {
                mLeDevices.add(device);
                mLeRssi.add(rssi);
            }

        }

        public BluetoothDevice getDevice(int position) {
            return mLeDevices.get(position);
        }

        public void clear() {
            mLeDevices.clear();
        }

        @Override
        public int getCount() {
            return mLeDevices.size();
        }

        @Override
        public Object getItem(int i) {
            return mLeDevices.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public int getViewTypeCount() {return 2;}

        @Override
        public int getItemViewType(int position) {
            return position % 2;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            Log.d(TAG, "getView: " + i);
            ViewHolder viewHolder;
            // General ListView optimization code.
            if (view == null) {
                view = mInflator.inflate(R.layout.listitem_device, null);
                viewHolder = new ViewHolder();
                viewHolder.deviceName = view.findViewById(R.id.device_name);
                viewHolder.rssiStrength = view.findViewById(R.id.rssi_strength);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }

            BluetoothDevice device = mLeDevices.get(i);
            Cursor res = myDb.readDevice(mLeDevices.get(i).getAddress());
            if(res.getCount() == 0){
                deviceName = device.getName();
            }

            while(res.moveToNext()) {
                deviceName = res.getString(res.getColumnIndex("EDITNAME"));
            }

            if (deviceName != null && deviceName.length() > 0)
                viewHolder.deviceName.setText(deviceName);
            else
                viewHolder.deviceName.setText(R.string.unknown_device);

            int rssi = mLeRssi.get(i);

            if (rssi >= -30) {
                viewHolder.rssiStrength.setImageResource(R.drawable.ic_signal_wifi_4_bar_black_24dp);
            } else if (rssi >= -50) {
                viewHolder.rssiStrength.setImageResource(R.drawable.ic_signal_wifi_3_bar_black_24dp);
            } else if (rssi >= -75) {
                viewHolder.rssiStrength.setImageResource(R.drawable.ic_signal_wifi_2_bar_black_24dp);
            } else if (rssi >= -90) {
                viewHolder.rssiStrength.setImageResource(R.drawable.ic_signal_wifi_1_bar_black_24dp);
            }

            return view;
        }
    }

    // Device scan callback.
    private ScanCallback mLeScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            mLeDeviceListAdapter.addDevice(result.getDevice(), result.getRssi());

            mLeDeviceListAdapter.notifyDataSetChanged();
        }

        public void onScanFailed(int errorCode) {
            switch (errorCode) {
                case SCAN_FAILED_ALREADY_STARTED:
                    Log.d(TAG, "Already started");
                    break;
                case SCAN_FAILED_APPLICATION_REGISTRATION_FAILED:
                    Log.d(TAG, "Cannot be registered");
                    break;
                case SCAN_FAILED_FEATURE_UNSUPPORTED:
                    Log.d(TAG, "Power optimized scan not supported");
                    break;
                case SCAN_FAILED_INTERNAL_ERROR:
                    Log.d(TAG, "Internal error");
                    break;
            }
        }
    };

    static class ViewHolder {
        TextView deviceName;
        ImageView rssiStrength;
    }
}
