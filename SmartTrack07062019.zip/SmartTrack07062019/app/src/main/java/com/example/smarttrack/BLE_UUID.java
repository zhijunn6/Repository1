package com.example.smarttrack;

public class BLE_UUID {
        public static final String SERVICE_INFORMATION = "82e288b2-d56a-4a9a-ad8b-6e30fdd2a5c3";
        public static final String CHAR_LIGHT_INTENSITY = "bb49e06b-7776-4d01-9e8b-a17539eb77c1";
        public static final String CHAR_LIGHT_COLOR = "161340df-ca55-4eba-88e1-2f3438037c2b";
        public static final String CHAR_MOTOR1_SPEED = "7db6776e-c0c2-4cd5-8091-4b2d3bbe74c9";
        public static final String CHAR_MOTOR2_SPEED = "61c96e92-3f77-46f2-a4ce-e81d4a92ff8b";
        public static final String CHAR_MOTOR1_DIR = "93378965-3bed-44ca-aa4c-1004b568e4b8";
        public static final String CHAR_MOTOR2_DIR = "9c89587f-a9b4-47f8-838d-349888cc80c7";
        public static final String LASER = "e5b18a21-1e59-41c1-93e8-6cabab8ca444";
        public static final String LOAD_MEMORY = "0e23c719-e717-4ec4-a1c2-9665bafe1cc8";
        public static final String SAVE_MEMORY = "2877c096-dcdb-4a40-bd28-bcf0669c8a4e";
}
