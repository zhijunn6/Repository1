package com.example.smarttrack;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class LanguageSelectionActivity extends AppCompatActivity {
    Button selectEng, selectFrc, selectIta, selectChn;
    private static final int REQUEST_FINE_LOCATION = 1;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_selection);

        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)){
                Toast.makeText(this, "The permission to get BLE location data is required", Toast.LENGTH_SHORT).show();
            }else{
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        }else{
            Toast.makeText(this, "Location permissions already granted", Toast.LENGTH_SHORT).show();
        }

        // Check Fine Location
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_FINE_LOCATION);
            }
        }

        // Use this check to determine whether BLE is supported on the device.  Then you can
        // selectively disable BLE-related features.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            AlertDialog alertDialog = new AlertDialog.Builder(LanguageSelectionActivity.this).create();
            alertDialog.setTitle("Alert");
            alertDialog.setMessage("BLE is not supported on this device");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
            alertDialog.show();
        }

        selectEng = findViewById(R.id.selectEngButton);
        selectFrc = findViewById(R.id.selectFrcButton);
        selectIta = findViewById(R.id.selectItaButton);
        selectChn = findViewById(R.id.selectChnButton);

        selectEng.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                setLocale("en");
                startActivity(new Intent(LanguageSelectionActivity.this, DeviceScanActivity.class));
            }
        });

        selectFrc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                setLocale("fr");
                startActivity(new Intent(LanguageSelectionActivity.this, DeviceScanActivity.class));
            }
        });

        selectIta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                setLocale("it");
                startActivity(new Intent(LanguageSelectionActivity.this, DeviceScanActivity.class));
            }
        });

        selectChn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                setLocale("zh");
                startActivity(new Intent(LanguageSelectionActivity.this, DeviceScanActivity.class));
            }
        });

        if(Build.VERSION.SDK_INT >= 21) {
            Toast.makeText(this, "This device has an SDK of " + Build.VERSION.SDK_INT, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "This device has SDK of " + Build.VERSION.SDK_INT, Toast.LENGTH_SHORT).show();
        }
    }

    public void setLocale(String lang) {
//        Locale myLocale = new Locale(lang);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
//        conf.locale = myLocale;
//        res.updateConfiguration(conf, dm);
//        Intent refresh = new Intent(this, LanguageSelectionActivity.class);
//        finish();
//        startActivity(refresh);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1){
            conf.setLocale(new Locale(lang.toLowerCase()));
        }
        else{
            conf.locale = new Locale(lang.toLowerCase());
        }
        res.updateConfiguration(conf, dm);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.finishAffinity();
    }
}
