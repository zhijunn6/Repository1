package com.example.smarttrack;

import android.app.Application;
import android.content.Intent;

public class serviceApplication extends Application {
    public BluetoothLeService mBluetoothLeService;

    @Override
    public void onCreate() {
        super.onCreate();
        mBluetoothLeService = new BluetoothLeService();
    }
}
